package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Approve_Appointment extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JTextField textField;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Approve_Appointment frame = new Approve_Appointment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Approve_Appointment() {
		setTitle("Approve Appointment");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 579, 383);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		
		lblNewLabel = new JLabel("Enter Appointment ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(68, 141, 132, 41);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(266, 150, 143, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		btnNewButton = new JButton("Approve");
		 btnNewButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                String appointmentIDStr = textField.getText().trim();

	                if (appointmentIDStr.isEmpty()) {
	                    JOptionPane.showMessageDialog(null, "Please enter an Appointment ID.");
	                    return;
	                }

	                try {
	                    int appointmentID = Integer.parseInt(appointmentIDStr);
	                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

	                    // Check the current status of the appointment
	                    String checkStatusQuery = "SELECT Status FROM appointment WHERE Appointment_ID = ?";
	                    PreparedStatement checkStatusStmt = con.prepareStatement(checkStatusQuery);
	                    checkStatusStmt.setInt(1, appointmentID);
	                    ResultSet rs = checkStatusStmt.executeQuery();

	                    if (rs.next()) {
	                        String currentStatus = rs.getString("Status");
	                        if (currentStatus.equalsIgnoreCase("Pending")) {
	                            // Update the status to Approved
	                            String updateStatusQuery = "UPDATE appointment SET Status = 'Approved' WHERE Appointment_ID = ?";
	                            PreparedStatement updateStatusStmt = con.prepareStatement(updateStatusQuery);
	                            updateStatusStmt.setInt(1, appointmentID);
	                            int rowsAffected = updateStatusStmt.executeUpdate();

	                            if (rowsAffected > 0) {
	                                JOptionPane.showMessageDialog(null, "Appointment with ID " + appointmentID + " has been approved \n Redirecting to staff page ");
	                                Staff_1 obj1=new Staff_1();
	                                obj1.setVisible(true);
	                                dispose();
	                            } else {
	                                JOptionPane.showMessageDialog(null, "Failed to update appointment status.");
	                            }

	                            updateStatusStmt.close();
	                        } else {
	                            JOptionPane.showMessageDialog(null, "Appointment with ID " + appointmentID + " is already approved.");
	                        }
	                    } else {
	                        JOptionPane.showMessageDialog(null, "Appointment ID not found.");
	                    }

	                    rs.close();
	                    checkStatusStmt.close();
	                    con.close();

	                } catch (NumberFormatException ex) {
	                    JOptionPane.showMessageDialog(null, "Invalid Appointment ID. Please enter a valid numeric ID.");
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
	                }
	            }
	        });
		btnNewButton.setBounds(195, 233, 108, 35);
		contentPane.add(btnNewButton);
		
	}

}

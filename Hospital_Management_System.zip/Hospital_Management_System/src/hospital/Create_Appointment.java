package hospital;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Create_Appointment extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Create_Appointment frame = new Create_Appointment();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Create_Appointment() {
        setTitle("Create an Appointment");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 806, 476);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblNewLabel = new JLabel("Enter Appointment ID");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel.setBounds(82, 69, 130, 25);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(253, 70, 142, 25);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("Enter Date (yyyy-MM-dd HH:mm:ss)");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel_1.setBounds(82, 213, 200, 18);
        contentPane.add(lblNewLabel_1);

        textField_1 = new JTextField();
        textField_1.setBounds(253, 136, 142, 25);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("Enter Patient ID");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel_2.setBounds(82, 132, 130, 31);
        contentPane.add(lblNewLabel_2);

        textField_2 = new JTextField();
        textField_2.setBounds(253, 211, 142, 25);
        contentPane.add(textField_2);
        textField_2.setColumns(10);

        JLabel lblNewLabel_3 = new JLabel("Enter Illness");
        lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel_3.setBounds(82, 291, 130, 25);
        contentPane.add(lblNewLabel_3);

        textField_3 = new JTextField();
        textField_3.setBounds(253, 295, 142, 25);
        contentPane.add(textField_3);
        textField_3.setColumns(10);

        JButton btnNewButton = new JButton("Create Appointment");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int appointmentId = Integer.parseInt(textField.getText());
                    int patientId = Integer.parseInt(textField_2.getText());
                    String dateStr = textField_1.getText();
                    String illness = textField_3.getText();

                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date parsedDate = dateFormat.parse(dateStr);
                    Timestamp appointmentTime = new Timestamp(parsedDate.getTime());

                    int departmentId3 = getDepartmentIdByIllness(illness);

                    if (departmentId3 == -1) {
                        JOptionPane.showMessageDialog(contentPane, "Invalid Illness. Please enter a valid illness.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    int doctorId2 = getDoctorIdByDepartmentId(departmentId3);

                    if (doctorId2 == -1) {
                        JOptionPane.showMessageDialog(contentPane, "No doctor available for this department.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    int staffId2 = getManagementStaffId();

                    insertIntoAppointment(appointmentId, appointmentTime, "Pending", doctorId2, staffId2, patientId);

                    JOptionPane.showMessageDialog(contentPane, "Appointment created successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid input. Please enter valid values.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (ParseException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid date format. Please enter date in 'yyyy-MM-dd HH:mm:ss' format.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(contentPane, "Error creating appointment.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        btnNewButton.setBounds(365, 367, 171, 48);
        contentPane.add(btnNewButton);
    }

    private int getDepartmentIdByIllness(String illness) {
        switch (illness.toLowerCase()) {
            case "ENT":
                return 199904;
            case "Cardiology":
                return 200101;
            case "Neurology":
                return 200302;
            case "Orthopaedics":
                return 200303;
            case "Gynechology":
                return 202205;
            default:
                return -1; // Invalid illness
        }
    }

    private int getDoctorIdByDepartmentId(int departmentId) throws SQLException {
        // Database query to retrieve Doctor_ID based on Department_ID
        int doctorId = -1; // Default value for no doctor found
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
            String sql = "SELECT Doctor_ID FROM works WHERE Department_ID = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, departmentId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                doctorId = rs.getInt("Doctor_ID");
            }
        } finally {
            // Close resources
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return doctorId;
    }

    private int getManagementStaffId() throws SQLException {
        // Database query to retrieve Staff_ID for Management Staff
        int staffId = -1; // Default value for no management staff found
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
            String sql = "SELECT Staff_ID FROM staff WHERE Type = 'Management Staff'";
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                staffId = rs.getInt("Staff_ID");
            }
        } finally {
            // Close resources
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return staffId;
    }

    private void insertIntoAppointment(int appointmentId, Timestamp date, String status, int doctorId2, int staffId2, int patientId) throws SQLException {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
            String sql = "INSERT INTO appointment (Appointment_ID, Date, Status, Doctor_ID2, Staff_ID2, Patient_ID2) VALUES (?, ?, ?, ?, ?, ?)";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, appointmentId);
            pstmt.setTimestamp(2, date);
            pstmt.setString(3, status);
            pstmt.setInt(4, doctorId2);
            pstmt.setInt(5, staffId2);
            pstmt.setInt(6, patientId);
            pstmt.executeUpdate();
        } finally {
            // Close resources
            if (pstmt != null) {
                pstmt.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }
}

package hospital;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class Current_Doc extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Current_Doc frame = new Current_Doc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Current_Doc() {
		setTitle("Current Doctors in Hospital");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 773, 483);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		
		table = new JTable();
		table.setBounds(92, 163, 371, -101);
		contentPane.add(table);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(67, 20, 660, 381);
		contentPane.add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		DefaultTableModel model=(DefaultTableModel) table_1.getModel();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system","root","harsh@123");
			Statement st=con.createStatement();
			String query="select * from doctor";
			ResultSet rs=st.executeQuery(query);
			ResultSetMetaData rsmd=rs.getMetaData();
			
			int cols=rsmd.getColumnCount();
			String[] colName=new String[cols];
			for(int i=0;i<cols;i++)
			{
				colName[i]=rsmd.getColumnName(i+1);
			}
			model.setColumnIdentifiers(colName);
			
			String p_id,p_ye,p_age,p_gen,p_phone,p_qual;
			String p_name,p_address;
			while(rs.next()) {
				p_id=rs.getString(1);
				p_name=rs.getString(2);
				p_age=rs.getString(4);
				p_gen=rs.getString(3);
				p_qual=rs.getString(5);
				p_phone=rs.getString(7);
				p_address=rs.getString(6);
				p_ye=rs.getString(8);
				String[] row= {p_id,p_name,p_gen,p_age,p_qual,p_address,p_phone,p_ye};
				model.addRow(row);
			}
			st.close();
			con.close();
			
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

}

package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Delete_Nurse extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Delete_Nurse frame = new Delete_Nurse();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Delete_Nurse() {
		setTitle("Delete Nurse");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 552, 355);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		
		setContentPane(contentPane);
		
		textField = new JTextField();
		textField.setBounds(242, 137, 96, 23);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Enter Nurse Id");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(105, 135, 96, 26);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Delete Nurse");
		btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the Nurse_ID entered by the user
                String nurseIdString = textField.getText().trim();

                // Validate input
                if (nurseIdString.isEmpty()) {
                    JOptionPane.showMessageDialog(contentPane, "Please enter Nurse ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Parse the Nurse_ID to an integer
                int nurseId = 0;
                try {
                    nurseId = Integer.parseInt(nurseIdString);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid Nurse ID format. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Delete the nurse record from the database based on the provided Nurse_ID
                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

                    // Use PreparedStatement to handle SQL parameterization
                    String sql = "DELETE FROM nurse WHERE Nurse_ID = ?";
                    PreparedStatement pstmt = con.prepareStatement(sql);
                    pstmt.setInt(1, nurseId);

                    int rowsDeleted = pstmt.executeUpdate();
                    if (rowsDeleted > 0) {
                        JOptionPane.showMessageDialog(contentPane, "Nurse with ID " + nurseId + " deleted successfully \n  Redirecting to staff page", "Success", JOptionPane.INFORMATION_MESSAGE);
                        Staff_1 obj1=new Staff_1();
                        obj1.setVisible(true);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(contentPane, "No nurse found with ID " + nurseId, "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    pstmt.close();
                    con.close();

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(contentPane, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(171, 208, 119, 44);
		contentPane.add(btnNewButton);
		
		
	}

}

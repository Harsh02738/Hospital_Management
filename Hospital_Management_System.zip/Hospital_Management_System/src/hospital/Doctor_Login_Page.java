package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class Doctor_Login_Page extends JFrame {

	private JPanel contentPane;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Doctor_Login_Page frame = new Doctor_Login_Page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Doctor_Login_Page() {
		setResizable(false);
		setFont(new Font("Arial", Font.PLAIN, 15));
		setTitle("Doctor Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 689, 436);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		
		setContentPane(contentPane);
		
		JLabel lblNewLabel_1 = new JLabel("Enter your ID");
		lblNewLabel_1.setBounds(141, 198, 117, 13);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Welcome Doctor ");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel_2.setBounds(77, 71, 504, 54);
		contentPane.add(lblNewLabel_2);
		
		passwordField = new JPasswordField();
		passwordField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String password=passwordField.getText();
				int flag=0;
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system","root","harsh@123");
					Statement st=con.createStatement();
					String query="select Doctor_ID from doctor";
					ResultSet rs=st.executeQuery(query);
					ResultSetMetaData rsmd=rs.getMetaData();
					
					
					String p_id;
					
					while(rs.next()) {
						p_id=rs.getString(1);
						if(p_id.equals(password))
						{
							flag=1;
							break;
						}
								
					}
					if(flag==0)
					{
						JOptionPane.showMessageDialog(rootPane,"Incorrect doctor id");
					}
					else {
						JOptionPane.showMessageDialog(rootPane,"Registered doctor");
					}
					
					st.close();
					con.close();
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		passwordField.setBounds(268, 195, 96, 19);
		contentPane.add(passwordField);
		
		JLabel lblNewLabel = new JLabel("Press enter to continue");
		lblNewLabel.setBounds(274, 245, 151, 13);
		contentPane.add(lblNewLabel);
	}

}

package hospital;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Give_Feed extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Give_Feed frame = new Give_Feed();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Give_Feed() {
        setTitle("Feedback form");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 771, 470);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        setContentPane(contentPane);

        JLabel lblNewLabel = new JLabel("Enter Description");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel.setBounds(114, 83, 108, 30);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setHorizontalAlignment(SwingConstants.LEFT);
        textField.setBounds(272, 67, 231, 66);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("Enter Date ");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel_1.setBounds(116, 186, 145, 23);
        contentPane.add(lblNewLabel_1);

        textField_1 = new JTextField();
        textField_1.setBounds(272, 189, 160, 20);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("Enter Appointment Id");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel_2.setBounds(114, 264, 131, 30);
        contentPane.add(lblNewLabel_2);

        textField_2 = new JTextField();
        textField_2.setBounds(272, 269, 160, 23);
        contentPane.add(textField_2);
        textField_2.setColumns(10);

        JButton btnNewButton = new JButton("Submit");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String description = textField.getText();
                String dateStr = textField_1.getText();
                String appointmentIdStr = textField_2.getText();

                try {
                    int appointmentId = Integer.parseInt(appointmentIdStr);

                    // Validate appointment ID and check status
                    String appointmentStatus = getAppointmentStatus(appointmentId);

                    if (appointmentStatus == null) {
                        JOptionPane.showMessageDialog(contentPane, "Appointment ID does not exist. Feedback not created.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    if (appointmentStatus.equalsIgnoreCase("Pending")) {
                        JOptionPane.showMessageDialog(contentPane, "Appointment is pending. Cannot create feedback.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Generate a random feedback ID (2-digit, not equal to 10)
                    Random random = new Random();
                    int feedbackId;
                    do {
                        feedbackId = random.nextInt(90) + 10;
                    } while (feedbackId == 10);

                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date date = dateFormat.parse(dateStr);
                    java.sql.Timestamp timestamp = new java.sql.Timestamp(date.getTime());

                    // Insert feedback into feedback table
                    insertFeedback(feedbackId, description, timestamp, appointmentId);

                    JOptionPane.showMessageDialog(contentPane, "Feedback successfully created\n Redirecting to patient page", "Success", JOptionPane.INFORMATION_MESSAGE);
                    Patient_1 obj1=new Patient_1();
                    obj1.setVisible(true);
                    dispose();

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid Appointment ID. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(contentPane, "Error occurred while creating feedback.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton.setBounds(307, 348, 94, 30);
        contentPane.add(btnNewButton);
    }

    private String getAppointmentStatus(int appointmentId) throws SQLException {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String status = null;

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
            String sql = "SELECT Status FROM appointment WHERE Appointment_ID = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, appointmentId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                status = rs.getString("Status");
            }

        } finally {
            // Close resources
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return status;
    }

    private void insertFeedback(int feedbackId, String description, java.sql.Timestamp date, int appointmentId) throws SQLException {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
            String sql = "INSERT INTO feeback (Feedback_ID, Description, Date, Appointment_ID2) VALUES (?, ?, ?, ?)";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, feedbackId);
            pstmt.setString(2, description);
            pstmt.setTimestamp(3, date);
            pstmt.setInt(4, appointmentId);
            pstmt.executeUpdate();

        } finally {
            // Close resources
            if (pstmt != null) {
                pstmt.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }
}

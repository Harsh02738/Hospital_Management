package hospital;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;

public class New_Bill extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					New_Bill frame = new New_Bill();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public New_Bill() {
		setTitle("New Bill generation");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 538, 368);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		JLabel lblNewLabel = new JLabel("Enter Amount");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setBounds(42, 66, 120, 29);
		contentPane.add(lblNewLabel);
		
		

		
		
		JLabel lblNewLabel_1 = new JLabel("Enter Description");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(42, 105, 88, 29);
		contentPane.add(lblNewLabel_1);
		
		
		
		
		JLabel lblNewLabel_2 = new JLabel("Enter Date");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2.setBounds(42, 141, 79, 29);
		contentPane.add(lblNewLabel_2);
		
		
		
		
		JLabel lblNewLabel_3 = new JLabel("Enter Staff ID");
		lblNewLabel_3.setBounds(42, 185, 139, 16);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_6 = new JLabel("Creation Form for new bill");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(10, 10, 476, 51);
		contentPane.add(lblNewLabel_6);
		
		
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        int amount = Integer.parseInt(textField.getText());
		        String description = textField_1.getText();
		        String dateStr = textField_2.getText(); // Assuming date in format: "yyyy-MM-dd HH:mm:ss"
		        int Staff_ID = Integer.parseInt(textField_3.getText());

		        // Validate Staff_ID by checking against the staff table
		        try {
		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

		            String staffQuery = "SELECT * FROM staff WHERE Staff_ID = ?";
		            PreparedStatement staffStmt = con.prepareStatement(staffQuery);
		            staffStmt.setInt(1, Staff_ID);
		            ResultSet staffResult = staffStmt.executeQuery();

		            if (!staffResult.next()) {
		                // Staff_ID does not exist in staff table
		                JOptionPane.showMessageDialog(null, "Invalid Staff ID. Please enter a valid Staff ID.");
		                return; // Stop further processing if validation fails
		            }

		            // Parse date string to java.sql.Timestamp
		            java.sql.Timestamp timestamp = java.sql.Timestamp.valueOf(dateStr);

		            // Generate unique Bill_ID based on a random number
		            long randomNumber = new Random().nextInt(900000) + 100000;
		            long billID = randomNumber;

		            // Use PreparedStatement to handle SQL parameterization
		            String sql = "INSERT INTO bill (Bill_ID, Amount, Status, Description, Date, Staff_ID3) VALUES (?, ?, ?, ?, ?, ?)";
		            PreparedStatement pstmt = con.prepareStatement(sql);
		            pstmt.setLong(1, billID);           // Bill_ID
		            pstmt.setInt(2, amount);            // Amount
		            pstmt.setString(3, "No");           // Status (initially null)
		            pstmt.setString(4, description);    // Description
		            pstmt.setTimestamp(5, timestamp);    // Date as Timestamp
		            pstmt.setInt(6, Staff_ID);           // Staff_ID

		            int rowsInserted = pstmt.executeUpdate();
		            if (rowsInserted > 0) {
		                JOptionPane.showMessageDialog(null, "Successfully created!\nBill ID is: " + billID + "\nRedirecting to staff page.");
		                Staff_1 obj1 = new Staff_1();
		                obj1.setVisible(true);
		                dispose();
		            } else {
		                JOptionPane.showMessageDialog(null, "Registration failed");
		            }

		            pstmt.close();
		            con.close();

		        } catch (SQLException ex) {
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
		        } catch (NumberFormatException ex) {
		            JOptionPane.showMessageDialog(null, "Invalid input for amount or Staff ID");
		        }
		    }
		});


		btnNewButton.setBounds(197, 233, 85, 21);
		contentPane.add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(172, 71, 139, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(172, 110, 139, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(172, 146, 139, 19);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(172, 184, 139, 19);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
	}

}

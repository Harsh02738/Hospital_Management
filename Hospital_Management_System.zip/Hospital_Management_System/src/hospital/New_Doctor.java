package hospital;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class New_Doctor extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					New_Doctor frame = new New_Doctor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public New_Doctor() {
		setTitle("New Doctor Registeration");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 744, 493);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		
		

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Enter your name");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setBounds(42, 66, 120, 29);
		contentPane.add(lblNewLabel);
		
		

		
		
		JLabel lblNewLabel_1 = new JLabel("Enter Gender");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(42, 105, 88, 29);
		contentPane.add(lblNewLabel_1);
		
		
		
		
		JLabel lblNewLabel_2 = new JLabel("Enter Age");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2.setBounds(42, 153, 79, 29);
		contentPane.add(lblNewLabel_2);
		
		
		
		JLabel lblNewLabel_3 = new JLabel("Enter Qualification");
		lblNewLabel_3.setBounds(42, 205, 123, 13);
		contentPane.add(lblNewLabel_3);
	
		
		JLabel lblNewLabel_4 = new JLabel("Enter Address");
		lblNewLabel_4.setBounds(42, 255, 88, 13);
		contentPane.add(lblNewLabel_4);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(10, 328, 45, -45);
		contentPane.add(textArea);
		
		
		JLabel lblNewLabel_5 = new JLabel("Years Of Experiance");
		lblNewLabel_5.setBounds(42, 366, 120, 19);
		contentPane.add(lblNewLabel_5);
		
	
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = textField.getText();
                int age = Integer.parseInt(textField_2.getText());
                String gender = textField_1.getText();
                String qual = textField_3.getText();
                long phone = Long.parseLong(textField_5.getText());
                String address = textField_4.getText();
                int years = Integer.parseInt(textField_6.getText());

                // Generate unique Doctor ID based on current year + qualification code + random number
             
                String qualificationCode = getQualificationCode(qual);
                int randomNumber = new Random().nextInt(9000) + 1000;
                long doctorId = Long.parseLong( qualificationCode + randomNumber);

                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

                    // Use PreparedStatement to handle SQL parameterization
                    String sql = "INSERT INTO doctor (Doctor_ID, Name, Gender, Age, Qualification, Address, Phone_No, Years_Of_Exp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement pstmt = con.prepareStatement(sql);
                    pstmt.setLong(1, doctorId);   // Doctor_ID
                    pstmt.setString(2, name);      // Name
                    pstmt.setString(3, gender);    // Gender
                    pstmt.setInt(4, age);    
                    pstmt.setString(5, qual);
                    pstmt.setString(6, address);   // Address
                    pstmt.setLong(7, phone);       // Phone_No
                    pstmt.setInt(8, years);  // Years_Of_Exp

                    int rowsInserted = pstmt.executeUpdate();
                    if (rowsInserted > 0) {
                        JOptionPane.showMessageDialog(null, "Successfully registered!\nYour Doctor ID is: " + doctorId + "\n Redirecting to staff page.");
                        Staff_1 obj1=new Staff_1();
                        obj1.setVisible(true);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Registration failed");
                    }

                    pstmt.close();
                    con.close();

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input for age, phone number, or years of experience");
                }
            }

			private String getQualificationCode(String qual) {
				// TODO Auto-generated method stub
				String code = "";
		        if (qual.contains("Gynecology")) {
		            code = "202205";
		        } else if (qual.contains("Neurology")) {
		            code = "200302";
		        } else if (qual.contains("Orthopaedics")) {
		            code = "200303";
		        } else if (qual.contains("Cardiology")) {
		            code = "200101";
		        } else if (qual.contains("ENT")) {
		            code = "199904";
		        }
		        return code;
				
			
			}
        });
		btnNewButton.setBounds(322, 417, 104, 29);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_6 = new JLabel("Registeration Form for new doctor");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(140, 10, 437, 51);
		contentPane.add(lblNewLabel_6);
		
		textField = new JTextField();
		textField.setBounds(193, 71, 104, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(193, 110, 104, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(193, 158, 104, 19);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(193, 202, 200, 29);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setHorizontalAlignment(SwingConstants.LEFT);
		textField_4.setBounds(196, 255, 444, 51);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Enter Phone Number");
		lblNewLabel_7.setBounds(42, 328, 120, 21);
		contentPane.add(lblNewLabel_7);
		
		textField_5 = new JTextField();
		textField_5.setBounds(195, 328, 123, 21);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(195, 366, 123, 19);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		
	}

}

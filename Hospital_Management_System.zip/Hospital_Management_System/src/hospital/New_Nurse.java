package hospital;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class New_Nurse extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					New_Nurse frame = new New_Nurse();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public New_Nurse() {
		setTitle("New nurse registeration");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 494, 359);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		JLabel lblNewLabel = new JLabel("Enter your name");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setBounds(42, 66, 120, 29);
		contentPane.add(lblNewLabel);
		
		

		
		
		JLabel lblNewLabel_1 = new JLabel("Enter Age");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(42, 105, 88, 29);
		contentPane.add(lblNewLabel_1);
		
		
		
		
		JLabel lblNewLabel_2 = new JLabel("Enter Gender");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2.setBounds(42, 141, 79, 29);
		contentPane.add(lblNewLabel_2);
		
		
		
		
		JLabel lblNewLabel_3 = new JLabel("Enter years of experiance");
		lblNewLabel_3.setBounds(42, 185, 139, 16);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_6 = new JLabel("Registeration Form for new staff");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(10, 10, 476, 51);
		contentPane.add(lblNewLabel_6);
		
		
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String name = textField.getText();
		        int age = Integer.parseInt(textField_1.getText());
		        String gender = textField_2.getText();
		        String qualification = textField_4.getText();
		        int years=Integer.parseInt(textField_3.getText());

		        // Validate the Type input
		       

		        // Generate unique Staff ID based on a random number
		        long randomNumber = new Random().nextInt(90000000) + 1000;
		        long nurseID = randomNumber;

		        try {
		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

		            // Use PreparedStatement to handle SQL parameterization
		            String sql = "INSERT INTO nurse (Nurse_ID, Name, Age, Gender, Years_Of_Exp, Qualification) VALUES (?, ?, ?, ?, ?, ?)";
		            PreparedStatement pstmt = con.prepareStatement(sql);
		            pstmt.setLong(1, nurseID);   // Staff_ID
		            pstmt.setString(2, name);    // Name
		            pstmt.setInt(3, age);        // Age
		            pstmt.setString(4, gender);
		            pstmt.setInt(5, years);
		            pstmt.setString(6, qualification);     // Type

		            int rowsInserted = pstmt.executeUpdate();
		            if (rowsInserted > 0) {
		                JOptionPane.showMessageDialog(null, "Successfully registered  !!\n Nurse ID is: " + nurseID + "\n Redirecting to staff page.");
		                Staff_1 obj1 = new Staff_1();
		                obj1.setVisible(true);
		                dispose();
		            } else {
		                JOptionPane.showMessageDialog(null, "Registration failed");
		            }

		            pstmt.close();
		            con.close();

		        } catch (SQLException ex) {
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
		        } catch (NumberFormatException ex) {
		            JOptionPane.showMessageDialog(null, "Invalid input for age or years of experiance ");
		        }
		    }

		    
		  
		});

		btnNewButton.setBounds(227, 278, 85, 21);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_4 = new JLabel("Enter Qualification");
		lblNewLabel_4.setBounds(42, 216, 120, 21);
		contentPane.add(lblNewLabel_4);
		
		textField = new JTextField();
		textField.setBounds(208, 71, 139, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(208, 110, 139, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(208, 146, 139, 19);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(208, 184, 139, 19);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(208, 217, 139, 19);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
	}

	

}

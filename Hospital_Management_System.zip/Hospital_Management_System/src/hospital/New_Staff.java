package hospital;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.util.Random;
import java.awt.event.ActionEvent;

public class New_Staff extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					New_Staff frame = new New_Staff();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public New_Staff() {
		setTitle("New Staff Registeration");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 561, 369);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Enter your name");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setBounds(42, 66, 120, 29);
		contentPane.add(lblNewLabel);
		
		

		
		
		JLabel lblNewLabel_1 = new JLabel("Enter Age");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(42, 105, 88, 29);
		contentPane.add(lblNewLabel_1);
		
		
		
		
		JLabel lblNewLabel_2 = new JLabel("Enter Gender");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2.setBounds(42, 141, 79, 29);
		contentPane.add(lblNewLabel_2);
		
		
		
		
		JLabel lblNewLabel_3 = new JLabel("Enter Type");
		lblNewLabel_3.setBounds(42, 185, 123, 16);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_6 = new JLabel("Registeration Form for new staff");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(10, 10, 476, 51);
		contentPane.add(lblNewLabel_6);
		
		textField = new JTextField();
		textField.setBounds(187, 71, 96, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(187, 110, 96, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(187, 146, 96, 19);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(187, 182, 96, 19);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String name = textField.getText();
		        int age = Integer.parseInt(textField_1.getText());
		        String gender = textField_2.getText();
		        String type = textField_3.getText();

		        // Validate the Type input
		        if (!isValidStaffType(type)) {
		            JOptionPane.showMessageDialog(null, "Invalid staff type. Please enter 'Peon', 'Management Staff', or 'Clerk'.");
		            return; // Stop processing further if validation fails
		        }

		        // Generate unique Staff ID based on a random number
		        int randomNumber = new Random().nextInt(9000) + 1000;
		        int staffId = randomNumber;

		        try {
		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

		            // Use PreparedStatement to handle SQL parameterization
		            String sql = "INSERT INTO staff (Staff_ID, Name, Age, Gender, Type) VALUES (?, ?, ?, ?, ?)";
		            PreparedStatement pstmt = con.prepareStatement(sql);
		            pstmt.setLong(1, staffId);   // Staff_ID
		            pstmt.setString(2, name);    // Name
		            pstmt.setInt(3, age);        // Age
		            pstmt.setString(4, gender);   // Gender
		            pstmt.setString(5, type);     // Type

		            int rowsInserted = pstmt.executeUpdate();
		            if (rowsInserted > 0) {
		                JOptionPane.showMessageDialog(null, "Successfully registered as "+type+" !!\n Staff ID is: " + staffId + "\n Redirecting to staff page.");
		                Staff_1 obj1 = new Staff_1();
		                obj1.setVisible(true);
		                dispose();
		            } else {
		                JOptionPane.showMessageDialog(null, "Registration failed");
		            }

		            pstmt.close();
		            con.close();

		        } catch (SQLException ex) {
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
		        } catch (NumberFormatException ex) {
		            JOptionPane.showMessageDialog(null, "Invalid input for age.");
		        }
		    }

		    // Method to validate the Staff Type
		    private boolean isValidStaffType(String type) {
		        return type.equalsIgnoreCase("Peon") ||
		               type.equalsIgnoreCase("Management Staff") ||
		               type.equalsIgnoreCase("Clerk");
		    }
		});

		btnNewButton.setBounds(241, 223, 85, 21);
		contentPane.add(btnNewButton);
		
	}

}

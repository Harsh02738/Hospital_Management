package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.Year;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class New__Patient extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					New__Patient frame = new New__Patient();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public New__Patient() {
		setResizable(false);
		setTitle("New Patient Registeration ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 697, 469);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Enter your name");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setBounds(42, 66, 120, 29);
		contentPane.add(lblNewLabel);
		
		
		String username;
		textField = new JTextField();
		username = textField.getText();
		textField.setBounds(208, 71, 96, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Age");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(42, 105, 88, 29);
		contentPane.add(lblNewLabel_1);
		
		
		textField_1 = new JTextField();
		textField_1.setBounds(208, 110, 96, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Enter Gender");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2.setBounds(42, 153, 79, 29);
		contentPane.add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.setBounds(208, 158, 96, 19);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Enter phone number");
		lblNewLabel_3.setBounds(39, 222, 123, 13);
		contentPane.add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setBounds(208, 219, 96, 19);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Enter Address");
		lblNewLabel_4.setBounds(42, 282, 88, 13);
		contentPane.add(lblNewLabel_4);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(10, 328, 45, -45);
		contentPane.add(textArea);
		
		textField_4 = new JTextField();
		textField_4.setBounds(210, 270, 437, 37);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Enter Insurance Id");
		lblNewLabel_5.setBounds(42, 356, 120, 13);
		contentPane.add(lblNewLabel_5);
		
		textField_5 = new JTextField();
		textField_5.setBounds(208, 353, 112, 19);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = textField.getText();
                int age = Integer.parseInt(textField_1.getText());
                String gender = textField_2.getText();
                long phone = Long.parseLong(textField_3.getText());
                String address = textField_4.getText();
                int insuranceId = Integer.parseInt(textField_5.getText());

                // Generate unique Patient ID based on current year + random number
                int currentYear = Year.now().getValue();
                int randomNumber = new Random().nextInt(9000) + 1000;
                long patientId = Long.parseLong(String.valueOf(currentYear) + randomNumber);

                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
                    
                    // Use PreparedStatement to handle SQL parameterization
                    String sql = "INSERT INTO patient (Patient_ID, Name, Age, Gender, Phone_No, Address, Insurance_ID) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement pstmt = con.prepareStatement(sql);
                    pstmt.setLong(1, patientId);   // Patient_ID
                    pstmt.setString(2, name);      // Name
                    pstmt.setInt(3, age);          // Age
                    pstmt.setString(4, gender);    // Gender
                    pstmt.setLong(5, phone);       // Phone_No
                    pstmt.setString(6, address);   // Address
                    pstmt.setInt(7, insuranceId);  // Insurance_ID

                    int rowsInserted = pstmt.executeUpdate();
                    if (rowsInserted > 0) {
                        JOptionPane.showMessageDialog(null, "Successfully registered ! \n Your id is "+ patientId +" \n Redirecting to login page");
                        Patient_Login_Page obj1=new Patient_Login_Page();
                        obj1.setVisible(true);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Registration failed");
                    }

                    pstmt.close();
                    con.close();

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input for age, phone number, or insurance ID");
                }
            }
        });
		btnNewButton.setBounds(322, 401, 85, 21);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_6 = new JLabel("Registeration Form for new patient");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(140, 10, 365, 51);
		contentPane.add(lblNewLabel_6);
	}
}


package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;
import java.awt.event.ActionEvent;

public class Patient_1 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Patient_1 frame = new Patient_1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Patient_1() {
		setTitle("View Patient");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 782, 488);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("Create Appointment");
		 btnNewButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                // Generate a random 5-digit Appointment ID
	                int appointmentId = generateUniqueAppointmentId();

	                // Display appropriate message based on the generated ID
	                if (appointmentId != -1) {
	                    JOptionPane.showMessageDialog(contentPane, "Unique Appointment ID created: " + appointmentId, "Success", JOptionPane.INFORMATION_MESSAGE);
	                } else {
	                    JOptionPane.showMessageDialog(contentPane, "Failed to create Appointment ID. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
	                }
	            }
	        });
		
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(48, 40, 152, 56);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Pay Bill");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Pay_Bill obj4=new Pay_Bill();
				obj4.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_1.setBounds(599, 44, 126, 49);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Give Feedback");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Give_Feed obj3=new Give_Feed();
				obj3.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(572, 358, 132, 56);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("View Medical History");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Med_History obj2=new View_Med_History();
				obj2.setVisible(true);
				dispose();
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_3.setBounds(33, 356, 180, 60);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("View Lab Results");
		btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Lab obj1=new View_Lab();
				obj1.setVisible(true);
				dispose();
			}
		});
		btnNewButton_4.setBounds(325, 358, 144, 56);
		contentPane.add(btnNewButton_4);
	}
		 private int generateUniqueAppointmentId() {
		        Random random = new Random();
		        int appointmentId = 0;

		        try {
		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

		            while (true) {
		                // Generate a random 5-digit number
		                appointmentId = 10000 + random.nextInt(90000);

		                // Check if the generated ID already exists in the appointment table
		                String sql = "SELECT * FROM appointment WHERE Appointment_ID = ?";
		                PreparedStatement pstmt = con.prepareStatement(sql);
		                pstmt.setInt(1, appointmentId);

		                ResultSet rs = pstmt.executeQuery();

		                // If no matching ID found, return the generated ID
		                if (!rs.next()) {
		                    pstmt.close();
		                    con.close();
		                    return appointmentId;
		                }
		                pstmt.close();
		            }
		        } catch (SQLException e) {
		            e.printStackTrace();
		            return -1; // Return -1 if an error occurs
		        }
		
		
	}

}

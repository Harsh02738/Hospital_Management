package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextPane;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Patient_Login_Page extends JFrame {

	private JPanel contentPane;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Patient_Login_Page frame = new Patient_Login_Page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Patient_Login_Page() {
		setResizable(false);
		setTitle("Patient Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 666, 469);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		
		
		setContentPane(contentPane);
		
		passwordField = new JPasswordField();
		passwordField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String password=passwordField.getText();
				int flag=0;
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system","root","harsh@123");
					Statement st=con.createStatement();
					String query="select Patient_ID from patient";
					ResultSet rs=st.executeQuery(query);
					ResultSetMetaData rsmd=rs.getMetaData();
					
					
					String p_id;
					
					while(rs.next()) {
						p_id=rs.getString(1);
						if(p_id.equals(password))
						{
							flag=1;
							break;
						}
								
					}
					if(flag==0)
					{
						JOptionPane.showMessageDialog(rootPane,"Incorrect patient id");
					}
					else {
						JOptionPane.showMessageDialog(rootPane,"Registered patient");
					}
					
					st.close();
					con.close();
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
			
			}
		});
		passwordField.setBounds(297, 197, 125, 19);
		contentPane.add(passwordField);
		
		JLabel lblNewLabel = new JLabel("Enter Your Patient Id");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(137, 185, 125, 43);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("If new patient click here");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(297, 342, 143, 19);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("Click here");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				New__Patient obj=new New__Patient();
				obj.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(454, 338, 103, 27);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("Welcome Patient");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel_2.setBounds(83, 56, 455, 93);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Press enter to continue");
		lblNewLabel_3.setBounds(297, 237, 158, 13);
		contentPane.add(lblNewLabel_3);
	}
}

package hospital;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;

public class Pay_Bill extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Pay_Bill frame = new Pay_Bill();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Pay_Bill() {
        setTitle("Pay Bill");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 541, 403);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        setContentPane(contentPane);

        JLabel lblNewLabel = new JLabel("Enter Patient Id");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel.setBounds(88, 78, 92, 26);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(248, 80, 148, 25);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("Enter Date (yyyy-MM-dd)");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel_1.setBounds(88, 138, 135, 26);
        contentPane.add(lblNewLabel_1);

        textField_1 = new JTextField();
        textField_1.setBounds(248, 142, 148, 21);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("Enter mode of payment");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel_2.setBounds(88, 195, 142, 21);
        contentPane.add(lblNewLabel_2);

        textField_2 = new JTextField();
        textField_2.setBounds(248, 197, 148, 19);
        contentPane.add(textField_2);
        textField_2.setColumns(10);

        JButton btnNewButton = new JButton("Pay Bill");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String patientIdStr = textField.getText();
                String dateStr = textField_1.getText();
                String modeOfPayment = textField_2.getText();

                try {
                    int patientId = Integer.parseInt(patientIdStr);

                    // Generate a random 6-digit bill ID
                    Random random = new Random();
                    int billId = random.nextInt(900000) + 100000;

                    // Format date string to SQL timestamp
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date date = dateFormat.parse(dateStr);
                    Timestamp timestamp = new Timestamp(date.getTime());

                    // Insert payment details into settles table
                    insertPayment(patientId, billId, timestamp, modeOfPayment);

                    JOptionPane.showMessageDialog(contentPane, "Bill payment recorded successfully\n Redirecting to patient page", "Success", JOptionPane.INFORMATION_MESSAGE);
                    Patient_1 obj1=new Patient_1();
                    obj1.setVisible(true);
                    dispose();

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid Patient ID. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(contentPane, "Error occurred while recording bill payment.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton.setBounds(197, 270, 114, 33);
        contentPane.add(btnNewButton);
    }

    private void insertPayment(int patientId, int billId, Timestamp date, String modeOfPayment) throws SQLException {
        Connection con = null;
        PreparedStatement pstmt = null;

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
            String sql = "INSERT INTO settles (Bill_ID, Patient_ID10, Date, ModeOfPayment) VALUES (?, ?, ?, ?)";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, billId);
            pstmt.setInt(2, patientId);
            pstmt.setTimestamp(3, date);
            pstmt.setString(4, modeOfPayment);
            pstmt.executeUpdate();

        } finally {
            // Close resources
            if (pstmt != null) {
                pstmt.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }
}

package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Remove_Doctor extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Remove_Doctor frame = new Remove_Doctor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Remove_Doctor() {
		setTitle("Remove doctor");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 675, 437);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Enter Doctor ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(101, 170, 128, 38);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(260, 180, 170, 31);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Remove");
		 btnNewButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                String doctorIDStr = textField.getText().trim();

	                if (doctorIDStr.isEmpty()) {
	                    JOptionPane.showMessageDialog(null, "Please enter a Doctor ID.");
	                    return;
	                }

	                try {
	                    int doctorID = Integer.parseInt(doctorIDStr);
	                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

	                    // Delete from the works table first (where Doctor_ID is a foreign key)
	                    String deleteWorksQuery = "DELETE FROM works WHERE Doctor_ID = ?";
	                    PreparedStatement deleteWorksStmt = con.prepareStatement(deleteWorksQuery);
	                    deleteWorksStmt.setInt(1, doctorID);
	                    deleteWorksStmt.executeUpdate();
	                    deleteWorksStmt.close();

	                    // Then delete from the doctor table
	                    String deleteDoctorQuery = "DELETE FROM doctor WHERE Doctor_ID = ?";
	                    PreparedStatement deleteDoctorStmt = con.prepareStatement(deleteDoctorQuery);
	                    deleteDoctorStmt.setInt(1, doctorID);
	                    int rowsAffected = deleteDoctorStmt.executeUpdate();

	                    if (rowsAffected > 0) {
	                        JOptionPane.showMessageDialog(null, "Doctor with ID " + doctorID + " has been removed \n Redirecting to Staff page");
	                        Staff_1 obj2=new Staff_1();
                            obj2.setVisible(true);
                            dispose();
	                    } else {
	                        JOptionPane.showMessageDialog(null, "Doctor ID not found.");
	                    }

	                    deleteDoctorStmt.close();
	                    con.close();

	                } catch (NumberFormatException ex) {
	                    JOptionPane.showMessageDialog(null, "Invalid Doctor ID. Please enter a valid numeric ID.");
	                } catch (SQLException ex) {
	                    ex.printStackTrace();
	                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
	                }
	            }
	        });
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(206, 262, 107, 38);
		contentPane.add(btnNewButton);
		
	}

}

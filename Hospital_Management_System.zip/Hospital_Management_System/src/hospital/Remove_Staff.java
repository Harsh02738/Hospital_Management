package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Remove_Staff extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Remove_Staff frame = new Remove_Staff();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Remove_Staff() {
		setTitle("Removing Staff");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 506, 333);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Enter Staff Id");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(88, 131, 103, 38);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(220, 139, 117, 25);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Remove Staff");
		btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the Staff_ID entered by the user
                String staffIdString = textField.getText().trim();

                // Validate input
                if (staffIdString.isEmpty()) {
                    // Handle empty input
                    JOptionPane.showMessageDialog(contentPane, "Please enter Staff ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Parse the Staff_ID to an integer
                int staffId = 0;
                try {
                    staffId = Integer.parseInt(staffIdString);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid Staff ID format. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Delete the staff record from the database based on the provided Staff_ID
                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

                    // Use PreparedStatement to handle SQL parameterization
                    String sql = "DELETE FROM staff WHERE Staff_ID = ?";
                    PreparedStatement pstmt = con.prepareStatement(sql);
                    pstmt.setInt(1, staffId);

                    int rowsDeleted = pstmt.executeUpdate();
                    if (rowsDeleted > 0) {
                        JOptionPane.showMessageDialog(contentPane, "Staff with ID " + staffId + " removed successfully\n Redirecting to Staff page", "Success", JOptionPane.INFORMATION_MESSAGE);
                        Staff_1 obj1=new Staff_1();
                        obj1.setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(contentPane, "No staff found with ID " + staffId, "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    pstmt.close();
                    con.close();

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(contentPane, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(158, 216, 117, 32);
		contentPane.add(btnNewButton);
		
		
	}

}

package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Staff_1 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Staff_1 frame = new Staff_1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Staff_1() {
		setTitle("Staff Interface");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 757, 448);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("View Current Doctors");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Current_Doc obj1=new Current_Doc();
				obj1.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(36, 108, 162, 68);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Add new Doctor");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				New_Doctor obj5=new New_Doctor();
				obj5.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_1.setBounds(31, 251, 184, 69);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("View Current Staff");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Current_Staff obj3=new Current_Staff();
				obj3.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_2.setBounds(276, 105, 167, 76);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Add new Staff");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				New_Staff obj6=new New_Staff();
				obj6.setVisible(true);
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_3.setBounds(276, 250, 167, 76);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("View Current Patients");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Current_Patients obj2=new Current_Patients();
				obj2.setVisible(true);
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_4.setBounds(513, 114, 162, 68);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("View Available Rooms");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Rooms obj4=new Rooms();
				obj4.setVisible(true);
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_5.setBounds(524, 251, 162, 76);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Next Page");
		btnNewButton_6.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Staff_2 obj7=new Staff_2();
				obj7.setVisible(true);
			}
		});
		btnNewButton_6.setBounds(598, 372, 120, 29);
		contentPane.add(btnNewButton_6);
		
		JLabel lblNewLabel = new JLabel("Welcome Staff ");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(33, 21, 630, 53);
		contentPane.add(lblNewLabel);
	}

}

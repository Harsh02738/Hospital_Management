package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class Staff_3 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Staff_3 frame = new Staff_3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Staff_3() {
		setTitle("Staff interface");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 797, 493);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("Approve Appointment");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Approve_Appointment obj5=new Approve_Appointment();
				obj5.setVisible(true);
			}
		});
		btnNewButton.setBounds(73, 295, 179, 59);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Update Bill Status");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Check_Bill obj4=new Check_Bill();
				obj4.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(348, 295, 139, 59);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Update Room Status");
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Update_Room obj3=new Update_Room();
				obj3.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(567, 295, 153, 59);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Remove Doctor");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Remove_Doctor obj4=new Remove_Doctor();
				obj4.setVisible(true);
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_3.setBounds(79, 387, 164, 59);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("View Appointment");
		btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Appointment obj6=new View_Appointment();
				obj6.setVisible(true);
			}
		});
		btnNewButton_4.setBounds(348, 387, 144, 59);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Remove Staff");
		btnNewButton_5.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Remove_Staff obj7=new Remove_Staff();
				obj7.setVisible(true);
				dispose();
			}
		});
		btnNewButton_5.setBounds(571, 387, 138, 59);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("View Current Inventory");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Inventory obj7=new View_Inventory();
				obj7.setVisible(true);
			}
		});
		btnNewButton_6.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_6.setBounds(61, 44, 173, 59);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("View Feedback");
		btnNewButton_7.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_Feedback obj8=new View_Feedback();
				obj8.setVisible(true);
			}
		});
		btnNewButton_7.setBounds(601, 44, 139, 59);
		contentPane.add(btnNewButton_7);
	}

}

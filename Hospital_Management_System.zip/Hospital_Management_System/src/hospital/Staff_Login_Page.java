package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Staff_Login_Page extends JFrame {

	private JPanel contentPane;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Staff_Login_Page frame = new Staff_Login_Page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Staff_Login_Page() {
		setResizable(false);
		setTitle("Staff Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 694, 428);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		
		

		setContentPane(contentPane);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Staff ID");
		lblNewLabel_1.setBounds(177, 196, 104, 31);
		contentPane.add(lblNewLabel_1);
		
		passwordField = new JPasswordField();
		passwordField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String password=passwordField.getText();
				int flag1=0;
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				try {
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system","root","harsh@123");
					Statement st=con.createStatement();
					String query="select Staff_ID,Type from staff";
					ResultSet rs=st.executeQuery(query);
					ResultSetMetaData rsmd=rs.getMetaData();
					
					
					String p_id,s_type;
					
					while(rs.next()) {
						p_id=rs.getString(1);
						s_type=rs.getString(2);
						if(p_id.equals(password))
						{
							flag1=1;
							if(s_type.equals("Peon"))
							{
								JOptionPane.showMessageDialog(rootPane,"Registered Peon");
							}
							else if(s_type.equals("Clerk"))
							{
								JOptionPane.showMessageDialog(rootPane,"Registered Clerk");
							}
							else if(s_type.equals("Management Staff"))
							{
								JOptionPane.showMessageDialog(rootPane,"Registered Manager , redirecting to new page");
								Staff_1 obj=new Staff_1();
								obj.setVisible(true);
								dispose();
							}
							break;
						}
								
					}
					if(flag1==0)
					{
						JOptionPane.showMessageDialog(rootPane,"Incorrect staff id");
					}
					
					
					st.close();
					con.close();
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		passwordField.setBounds(292, 202, 123, 19);
		contentPane.add(passwordField);
		
		JLabel lblNewLabel_2 = new JLabel("Welcome Staff");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(70, 47, 502, 87);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel = new JLabel("Press enter to continue");
		lblNewLabel.setBounds(319, 247, 190, 13);
		contentPane.add(lblNewLabel);
	}

}

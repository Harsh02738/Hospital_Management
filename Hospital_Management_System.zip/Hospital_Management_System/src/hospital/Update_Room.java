package hospital;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Update_Room extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Update_Room frame = new Update_Room();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Update_Room() {
        setTitle("Updating Room status");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 540, 416);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        setContentPane(contentPane);

        JLabel lblNewLabel = new JLabel("Enter Room Number");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel.setBounds(84, 128, 140, 49);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(234, 141, 127, 26);
        contentPane.add(textField);
        textField.setColumns(10);

        JButton btnNewButton = new JButton("Update");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String roomIDStr = textField.getText().trim();

                if (roomIDStr.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter a Room Number.");
                    return;
                }

                try {
                    int roomID = Integer.parseInt(roomIDStr);
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

                    // Check the current status of the room
                    String selectQuery = "SELECT Status FROM room WHERE Room_No = ?";
                    PreparedStatement selectStmt = con.prepareStatement(selectQuery);
                    selectStmt.setInt(1, roomID);

                    ResultSet rs = selectStmt.executeQuery();

                    if (rs.next()) {
                        String currentStatus = rs.getString("Status");
                        if (currentStatus.equalsIgnoreCase("Available")) {
                            // Room is available, update status to "Not Available"
                            String updateQuery = "UPDATE room SET Status = 'Not Available' WHERE Room_No = ?";
                            PreparedStatement updateStmt = con.prepareStatement(updateQuery);
                            updateStmt.setInt(1, roomID);
                            updateStmt.executeUpdate();

                            // Insert into allots table
                            String patientIDStr = textField_1.getText().trim();
                            String staffIDStr = textField_2.getText().trim();

                            int patientID = Integer.parseInt(patientIDStr);
                            int staffID = Integer.parseInt(staffIDStr);

                            if (isPatientIDValid(patientID) && isStaffIDValid(staffID)) {
                                String insertQuery = "INSERT INTO allots (Room_No, Patient_ID9, Staff_ID4) VALUES (?, ?, ?)";
                                PreparedStatement insertStmt = con.prepareStatement(insertQuery);
                                insertStmt.setInt(1, roomID);
                                insertStmt.setInt(2, patientID);
                                insertStmt.setInt(3, staffID);
                                insertStmt.executeUpdate();

                                JOptionPane.showMessageDialog(null, "Room is now booked.\nRedirecting to Staff page.");
                                Staff_1 staffPage = new Staff_1();
                                staffPage.setVisible(true);
                                dispose();
                            } else {
                                JOptionPane.showMessageDialog(null, "Invalid Patient ID or Staff ID.");
                            }
                        } else {
                            // Room is already booked
                            JOptionPane.showMessageDialog(null, "Room is already booked.\nRedirecting to Staff Page.");
                            Staff_1 staffPage = new Staff_1();
                            staffPage.setVisible(true);
                            dispose();
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Room ID not found.");
                    }

                    rs.close();
                    selectStmt.close();
                    con.close();

                } catch (NumberFormatException | SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                }
            }
        });
        btnNewButton.setBounds(176, 301, 99, 32);
        contentPane.add(btnNewButton);

        JLabel lblNewLabel_1 = new JLabel("Enter Patient Id");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel_1.setBounds(84, 188, 112, 26);
        contentPane.add(lblNewLabel_1);

        textField_1 = new JTextField();
        textField_1.setBounds(234, 193, 127, 21);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("Enter Staff Id");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel_2.setBounds(84, 241, 112, 34);
        contentPane.add(lblNewLabel_2);

        textField_2 = new JTextField();
        textField_2.setBounds(234, 247, 127, 25);
        contentPane.add(textField_2);
        textField_2.setColumns(10);
    }

    private boolean isPatientIDValid(int patientID) throws SQLException {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
        String query = "SELECT Patient_ID FROM patient WHERE Patient_ID = ?";
        PreparedStatement pstmt = con.prepareStatement(query);
        pstmt.setInt(1, patientID);
        ResultSet rs = pstmt.executeQuery();
        boolean isValid = rs.next();
        rs.close();
        pstmt.close();
        con.close();
        return isValid;
    }

    private boolean isStaffIDValid(int staffID) throws SQLException {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
        String query = "SELECT Staff_ID FROM staff WHERE Staff_ID = ?";
        PreparedStatement pstmt = con.prepareStatement(query);
        pstmt.setInt(1, staffID);
        ResultSet rs = pstmt.executeQuery();
        boolean isValid = rs.next();
        rs.close();
        pstmt.close();
        con.close();
        return isValid;
    }
}

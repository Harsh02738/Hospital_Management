package hospital;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class View_Appointment extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Appointment frame = new View_Appointment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public View_Appointment() {
		setTitle("View Appointment");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 772, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(60, 39, 641, 369);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		 DefaultTableModel model = (DefaultTableModel) table.getModel();

	        try {
	            // Establish connection to the database
	            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

	            // Create a Statement object for executing SQL queries
	            Statement st = con.createStatement();

	            // Define the SQL query to retrieve all records from the appointment table
	            String query = "SELECT * FROM appointment";

	            // Execute the query and obtain the ResultSet
	            ResultSet rs = st.executeQuery(query);

	            // Retrieve metadata about the ResultSet (e.g., column names)
	            ResultSetMetaData rsmd = rs.getMetaData();

	            // Get the number of columns in the ResultSet
	            int cols = rsmd.getColumnCount();

	            // Create an array to hold column names
	            String[] colNames = new String[cols];

	            // Populate the array with column names
	            for (int i = 0; i < cols; i++) {
	                colNames[i] = rsmd.getColumnName(i + 1);
	            }

	            // Set the column identifiers for the table model
	            model.setColumnIdentifiers(colNames);

	            // Iterate through the ResultSet to populate the table model with data
	            while (rs.next()) {
	                Object[] rowData = new Object[cols];
	                for (int i = 0; i < cols; i++) {
	                    rowData[i] = rs.getObject(i + 1);
	                }
	                model.addRow(rowData); // Add the row data to the table model
	            }

	            // Close the ResultSet, Statement, and Connection
	            rs.close();
	            st.close();
	            con.close();

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	}

}

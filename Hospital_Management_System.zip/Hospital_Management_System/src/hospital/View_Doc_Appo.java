package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class View_Doc_Appo extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTable table;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    View_Doc_Appo frame = new View_Doc_Appo();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public View_Doc_Appo() {
        setTitle("Viewing your Appointments");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 786, 479);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        setContentPane(contentPane);

        JLabel lblNewLabel = new JLabel("Enter Doctor Id");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel.setBounds(227, 129, 109, 34);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(385, 129, 131, 34);
        contentPane.add(textField);
        textField.setColumns(10);

        JButton btnNewButton = new JButton("View Appointment");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String doctorIdStr = textField.getText();

                try {
                    int doctorId = Integer.parseInt(doctorIdStr);

                    // Fetch appointments from database based on Doctor ID
                    DefaultTableModel model = new DefaultTableModel();
                    model.addColumn("Appointment ID");
                    model.addColumn("Date");
                    model.addColumn("Status");
                    model.addColumn("Staff ID");
                    model.addColumn("Patient ID");

                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
                    String sql = "SELECT Appointment_ID, Date, Status, Staff_ID2, Patient_ID2 FROM appointment WHERE Doctor_ID2 = ?";
                    PreparedStatement pstmt = con.prepareStatement(sql);
                    pstmt.setInt(1, doctorId);
                    ResultSet rs = pstmt.executeQuery();

                    while (rs.next()) {
                        int appointmentId = rs.getInt("Appointment_ID");
                        String date = rs.getString("Date");
                        String status = rs.getString("Status");
                        int staffId = rs.getInt("Staff_ID2");
                        int patientId = rs.getInt("Patient_ID2");

                        model.addRow(new Object[]{appointmentId, date, status, staffId, patientId});
                    }

                    table.setModel(model);
                    con.close();

                    JOptionPane.showMessageDialog(contentPane, "Appointments successfully fetched\n Redirecting to doctor page", "Success", JOptionPane.INFORMATION_MESSAGE);
                    Doctor_1 obj1=new Doctor_1();
                    obj1.setVisible(true);
                    dispose();

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid Doctor ID. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Error occurred while fetching appointments.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton.setBounds(288, 183, 138, 41);
        contentPane.add(btnNewButton);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(49, 242, 680, 177);
        contentPane.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);
    }
}

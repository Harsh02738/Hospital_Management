package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class View_Feedback extends JFrame {

    private JPanel contentPane;
    private JTable table;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    View_Feedback frame = new View_Feedback();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public View_Feedback() {
        setTitle("Viewing all feedbacks");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 776, 495);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        setContentPane(contentPane);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(34, 58, 679, 347);
        contentPane.add(scrollPane);

        // Define column names for the table
        String[] columnNames = {"Feedback ID", "Description", "Date", "Appointment ID"};

        // Create a DefaultTableModel with column names
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columnNames);

        // Populate table data from database
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
            String sql = "SELECT Feedback_ID, Description, Date, Appointment_ID2 FROM feeback";
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int feedbackId = rs.getInt("Feedback_ID");
                String description = rs.getString("Description");
                String date = rs.getString("Date");
                int appointmentId = rs.getInt("Appointment_ID2");

                // Add row to the table model
                model.addRow(new Object[]{feedbackId, description, date, appointmentId});
            }

            con.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Create JTable with the populated model
        table = new JTable(model);

        // Set the table to be scrollable
        scrollPane.setViewportView(table);
    }
}

package hospital;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class View_Inventory extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JTextField textField;
	private JTextField textField_1;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Inventory frame = new View_Inventory();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public View_Inventory() {
		setTitle("Viewing Inventory");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 774, 485);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(27, 29, 677, 276);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		lblNewLabel = new JLabel("Enter Item Id");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(166, 332, 96, 28);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Enter Quantity");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(166, 370, 103, 22);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(304, 337, 114, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(304, 373, 118, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		btnNewButton = new JButton("Update Quantity");
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String itemIDStr = textField.getText().trim();
		        String quantityStr = textField_1.getText().trim();

		        if (itemIDStr.isEmpty() || quantityStr.isEmpty()) {
		            JOptionPane.showMessageDialog(null, "Please enter both Item ID and Quantity.");
		            return;
		        }

		        try {
		            int itemID = Integer.parseInt(itemIDStr);
		            int quantity = Integer.parseInt(quantityStr);

		            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

		            // Check if the Item ID exists in the inventory table
		            String selectQuery = "SELECT * FROM inventory WHERE Item_ID = ?";
		            PreparedStatement selectStmt = con.prepareStatement(selectQuery);
		            selectStmt.setInt(1, itemID);

		            ResultSet rs = selectStmt.executeQuery();

		            if (rs.next()) {
		                // Item ID exists, update the Quantity
		                String updateQuery = "UPDATE inventory SET Quantity = ? WHERE Item_ID = ?";
		                PreparedStatement updateStmt = con.prepareStatement(updateQuery);
		                updateStmt.setInt(1, quantity);
		                updateStmt.setInt(2, itemID);

		                int updatedRows = updateStmt.executeUpdate();

		                if (updatedRows > 0) {
		                    // Quantity updated successfully
		                    JOptionPane.showMessageDialog(null, "Quantity changed successfully.\nRedirecting to Staff page.");
		                    Staff_1 staffPage = new Staff_1();
		                    staffPage.setVisible(true);
		                    dispose();
		                } else {
		                    JOptionPane.showMessageDialog(null, "Failed to update quantity. Please try again.");
		                }
		            } else {
		                JOptionPane.showMessageDialog(null, "Item ID not found in the inventory.");
		            }

		            // Close ResultSet, Statements, and Connection
		            rs.close();
		            selectStmt.close();
		            con.close();

		        } catch (NumberFormatException | SQLException ex) {
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
		        }
		    }
		});

		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(267, 410, 127, 28);
		contentPane.add(btnNewButton);
		DefaultTableModel model = (DefaultTableModel) table.getModel();

        try {
            // Establish connection to the database
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

            // Create a Statement object for executing SQL queries
            Statement st = con.createStatement();

            // Define the SQL query to retrieve all records from the appointment table
            String query = "SELECT * FROM inventory";

            // Execute the query and obtain the ResultSet
            ResultSet rs = st.executeQuery(query);

            // Retrieve metadata about the ResultSet (e.g., column names)
            ResultSetMetaData rsmd = rs.getMetaData();

            // Get the number of columns in the ResultSet
            int cols = rsmd.getColumnCount();

            // Create an array to hold column names
            String[] colNames = new String[cols];

            // Populate the array with column names
            for (int i = 0; i < cols; i++) {
                colNames[i] = rsmd.getColumnName(i + 1);
            }

            // Set the column identifiers for the table model
            model.setColumnIdentifiers(colNames);

            // Iterate through the ResultSet to populate the table model with data
            while (rs.next()) {
                Object[] rowData = new Object[cols];
                for (int i = 0; i < cols; i++) {
                    rowData[i] = rs.getObject(i + 1);
                }
                model.addRow(rowData); // Add the row data to the table model
            }

            // Close the ResultSet, Statement, and Connection
            rs.close();
            st.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
		
	}

}

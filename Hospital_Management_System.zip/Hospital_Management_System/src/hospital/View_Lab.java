package hospital;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

public class View_Lab extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTable table;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    View_Lab frame = new View_Lab();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public View_Lab() {
        setTitle("View Lab results");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 672, 470);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        setContentPane(contentPane);

        JLabel lblNewLabel = new JLabel("Enter Patient Id");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel.setBounds(149, 128, 112, 36);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(296, 135, 121, 26);
        contentPane.add(textField);
        textField.setColumns(10);

        JButton btnNewButton = new JButton("Get Lab Results");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String patientIdStr = textField.getText();

                try {
                    int patientId = Integer.parseInt(patientIdStr);

                    // Fetch lab results from lab table based on patient ID
                    fetchLabResults(patientId);

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid Patient ID. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton.setBounds(217, 192, 127, 36);
        contentPane.add(btnNewButton);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(35, 246, 593, 161);
        contentPane.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);

        // Set table model
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Lab ID");
        model.addColumn("Cost");
        model.addColumn("Description");
        model.addColumn("Date");
        table.setModel(model);
    }

    private void fetchLabResults(int patientId) {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
            String sql = "SELECT Lab_ID, Cost, Description, Date FROM lab WHERE Patient_ID8 = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, patientId);
            rs = pstmt.executeQuery();

            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setRowCount(0); // Clear previous table data

            while (rs.next()) {
                int labId = rs.getInt("Lab_ID");
                double cost = rs.getDouble("Cost");
                String description = rs.getString("Description");
                String date = rs.getString("Date");

                model.addRow(new Object[] { labId, cost, description, date });
            }

            JOptionPane.showMessageDialog(contentPane, "Lab results successfully fetched.", "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(contentPane, "Error retrieving lab results.", "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        } finally {
            // Close resources
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}

package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class View_Med_2 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Med_2 frame = new View_Med_2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public View_Med_2() {
		setTitle("View Medical History");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 490, 321);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Enter Record Id");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(66, 120, 102, 36);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Get Prescription Id ");
		btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String recordIdStr = textField.getText();

                try {
                    int recordId = Integer.parseInt(recordIdStr);

                    // Call method to retrieve Prescription_ID1 from record table
                    int prescriptionId = getPrescriptionIdByRecordId(recordId);

                    if (prescriptionId != -1) {
                        JOptionPane.showMessageDialog(contentPane, "Prescription ID: " + prescriptionId, "Prescription ID \n Redirecting to new page", JOptionPane.INFORMATION_MESSAGE);
                        View_Med_3 obj3=new View_Med_3();
                        obj3.setVisible(true);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(contentPane, "No prescription found for Record ID: " + recordId, "Error", JOptionPane.ERROR_MESSAGE);
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid Record ID. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Error retrieving prescription.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton.setBounds(126, 199, 139, 44);
        contentPane.add(btnNewButton);

        textField = new JTextField();
        textField.setBounds(211, 126, 102, 28);
        contentPane.add(textField);
        textField.setColumns(10);
    }

    private int getPrescriptionIdByRecordId(int recordId) throws SQLException {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int prescriptionId = -1; // Default value for no prescription found

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
            String sql = "SELECT Prescription_ID1 FROM record WHERE Record_ID = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, recordId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                prescriptionId = rs.getInt("Prescription_ID1");
            }
        } finally {
            // Close resources
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return prescriptionId;
    }
}

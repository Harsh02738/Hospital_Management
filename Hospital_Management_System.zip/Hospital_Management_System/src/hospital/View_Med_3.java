package hospital;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

public class View_Med_3 extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTable table;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    View_Med_3 frame = new View_Med_3();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public View_Med_3() {
        setTitle("Viewing Medical History");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 664, 444);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        setContentPane(contentPane);

        JLabel lblNewLabel = new JLabel("Enter Prescription Id");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel.setBounds(142, 109, 135, 26);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(306, 112, 124, 23);
        contentPane.add(textField);
        textField.setColumns(10);

        JButton btnNewButton = new JButton("Get History");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String prescriptionIdStr = textField.getText();

                try {
                    int prescriptionId = Integer.parseInt(prescriptionIdStr);

                    // Fetch medical history from prescription table
                    Object[] medicalHistory = getMedicalHistoryByPrescriptionId(prescriptionId);

                    if (medicalHistory != null) {
                        DefaultTableModel model = (DefaultTableModel) table.getModel();
                        model.addRow(new Object[] { prescriptionId, medicalHistory[0], medicalHistory[1] });

                        JOptionPane.showMessageDialog(contentPane, "Medical history successfully fetched\n Redirecting to Patient Page", "Success", JOptionPane.INFORMATION_MESSAGE);
                        Patient_1 obj1=new Patient_1();
                        obj1.setVisible(true);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(contentPane, "No medical history found for Prescription ID: " + prescriptionId, "Error", JOptionPane.ERROR_MESSAGE);
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid Prescription ID. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Error retrieving medical history.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });
        btnNewButton.setBounds(219, 182, 109, 41);
        contentPane.add(btnNewButton);

        // Create table with scroll pane
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 270, 628, 124);
        contentPane.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);

        // Set table model
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Prescription ID");
        model.addColumn("Description");
        model.addColumn("Doctor ID");
        table.setModel(model);
    }

    private Object[] getMedicalHistoryByPrescriptionId(int prescriptionId) throws SQLException {
        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Object[] medicalHistory = null;

        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
            String sql = "SELECT Description, Doctor_ID FROM prescription WHERE Prescription_ID = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, prescriptionId);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                String description = rs.getString("Description");
                int doctorId = rs.getInt("Doctor_ID");
                medicalHistory = new Object[] { description, doctorId };
            }
        } finally {
            // Close resources
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return medicalHistory;
    }
}

package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class View_Med_History extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_Med_History frame = new View_Med_History();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public View_Med_History() {
		setTitle("View Medical History");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 488, 338);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);

		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Enter Patient Id");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(68, 125, 95, 26);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(212, 127, 140, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Get Record Id");
		 btnNewButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                String patientIdStr = textField.getText();

	                try {
	                    int patientId = Integer.parseInt(patientIdStr);

	                    // Call method to retrieve Record_ID from med_history table
	                    int recordId = getRecordIdByPatientId(patientId);

	                    if (recordId != -1) {
	                        JOptionPane.showMessageDialog(contentPane, "Record ID: " + recordId, "Record ID \n Redirecting to next page", JOptionPane.INFORMATION_MESSAGE);
	                        View_Med_2 obj1=new View_Med_2();
	                        obj1.setVisible(true);
	                        dispose();
	                    } else {
	                        JOptionPane.showMessageDialog(contentPane, "No record found for Patient ID: " + patientId, "Error", JOptionPane.ERROR_MESSAGE);
	                    }

	                } catch (NumberFormatException ex) {
	                    JOptionPane.showMessageDialog(contentPane, "Invalid Patient ID. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
	                } catch (SQLException ex) {
	                    JOptionPane.showMessageDialog(contentPane, "Error retrieving record.", "Error", JOptionPane.ERROR_MESSAGE);
	                    ex.printStackTrace();
	                }
	            }
	        });
	        btnNewButton.setBounds(154, 187, 101, 42);
	        contentPane.add(btnNewButton);
	    }

	    private int getRecordIdByPatientId(int patientId) throws SQLException {
	        Connection con = null;
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        int recordId = -1; // Default value for no record found

	        try {
	            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
	            String sql = "SELECT Record_ID FROM med_history WHERE Patient_ID7 = ?";
	            pstmt = con.prepareStatement(sql);
	            pstmt.setInt(1, patientId);
	            rs = pstmt.executeQuery();

	            if (rs.next()) {
	                recordId = rs.getInt("Record_ID");
	            }
	        } finally {
	            // Close resources
	            if (rs != null) {
	                rs.close();
	            }
	            if (pstmt != null) {
	                pstmt.close();
	            }
	            if (con != null) {
	                con.close();
	            }
	        }

	        return recordId;
	    }
	}

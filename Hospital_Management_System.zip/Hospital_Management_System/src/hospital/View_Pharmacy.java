package hospital;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class View_Pharmacy extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private JLabel lblNewLabel;
    private JTextField textField;
    private JTextField textField_1;
    private JLabel lblNewLabel_1;
    private JButton btnNewButton;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    View_Pharmacy frame = new View_Pharmacy();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public View_Pharmacy() {
        setTitle("Viewing Pharmacy");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 815, 484);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(31, 31, 727, 269);
        contentPane.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);

        lblNewLabel = new JLabel("Enter Medicine Id");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel.setBounds(174, 320, 131, 29);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(315, 324, 105, 21);
        contentPane.add(textField);
        textField.setColumns(10);

        textField_1 = new JTextField();
        textField_1.setBounds(315, 360, 105, 19);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        lblNewLabel_1 = new JLabel("Enter Quantity");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel_1.setBounds(174, 359, 107, 21);
        contentPane.add(lblNewLabel_1);

        btnNewButton = new JButton("Update Quantity");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton.setBounds(290, 404, 131, 33);
        contentPane.add(btnNewButton);

        DefaultTableModel model = (DefaultTableModel) table.getModel();

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

            // Retrieve all records from the pharmacy table
            String query = "SELECT * FROM pharmacy";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            // Retrieve metadata about the ResultSet (e.g., column names)
            ResultSetMetaData rsmd = rs.getMetaData();

            // Get the number of columns in the ResultSet
            int cols = rsmd.getColumnCount();

            // Create an array to hold column names
            String[] colNames = new String[cols];

            // Populate the array with column names
            for (int i = 0; i < cols; i++) {
                colNames[i] = rsmd.getColumnName(i + 1);
            }

            // Set the column identifiers for the table model
            model.setColumnIdentifiers(colNames);

            // Iterate through the ResultSet to populate the table model with data
            while (rs.next()) {
                Object[] rowData = new Object[cols];
                for (int i = 0; i < cols; i++) {
                    rowData[i] = rs.getObject(i + 1);
                }
                model.addRow(rowData); // Add the row data to the table model
            }

            // Close the ResultSet, Statement, and Connection
            rs.close();
            st.close();
            con.close();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        // Action listener for the Submit button
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String medicineIDStr = textField.getText().trim();
                String quantityStr = textField_1.getText().trim();

                if (medicineIDStr.isEmpty() || quantityStr.isEmpty()) {
                    return; // Handle empty input fields
                }

                try {
                    int medicineID = Integer.parseInt(medicineIDStr);
                    int quantity = Integer.parseInt(quantityStr);

                    // Establish connection to the database
                    Connection con;
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");

                    // Prepare SQL update statement
                    String updateQuery = "UPDATE pharmacy SET Quantity = ? WHERE Medicine_ID = ?";
                    PreparedStatement pstmt = con.prepareStatement(updateQuery);
                    pstmt.setInt(1, quantity);
                    pstmt.setInt(2, medicineID);

                    // Execute update statement
                    int rowsUpdated = pstmt.executeUpdate();

                    if (rowsUpdated > 0) {
                        // Display success message or perform additional actions
    
                        JOptionPane.showMessageDialog(null, "Quantity updated successfully!\nRedirecting to Staff page.");
                        Staff_1 staffPage = new Staff_1();
                        staffPage.setVisible(true);
                        dispose();
                    }

                    // Close PreparedStatement and Connection
                    pstmt.close();
                    con.close();

                } catch (NumberFormatException | SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }
}

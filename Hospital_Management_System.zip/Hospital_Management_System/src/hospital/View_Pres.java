package hospital;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class View_Pres extends JFrame {

    private JPanel contentPane;
    private JTextField textField;
    private JTable table;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    View_Pres frame = new View_Pres();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public View_Pres() {
        setTitle("View all prescriptions");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 744, 454);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);

        setContentPane(contentPane);

        JLabel lblNewLabel = new JLabel("Enter Doctor Id");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
        lblNewLabel.setBounds(212, 102, 105, 33);
        contentPane.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(369, 107, 125, 26);
        contentPane.add(textField);
        textField.setColumns(10);

        JButton btnNewButton = new JButton("Get Prescriptions");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String doctorIdStr = textField.getText();

                try {
                    int doctorId = Integer.parseInt(doctorIdStr);

                    // Fetch prescriptions from database based on Doctor ID
                    DefaultTableModel model = new DefaultTableModel();
                    model.addColumn("Prescription ID");
                    model.addColumn("Description");
                    model.addColumn("Patient ID");

                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital_management_system", "root", "harsh@123");
                    String sql = "SELECT Prescription_ID, Description, Patient_ID FROM prescription WHERE Doctor_ID = ?";
                    PreparedStatement pstmt = con.prepareStatement(sql);
                    pstmt.setInt(1, doctorId);
                    ResultSet rs = pstmt.executeQuery();

                    while (rs.next()) {
                        int prescriptionId = rs.getInt("Prescription_ID");
                        String description = rs.getString("Description");
                        int patientId = rs.getInt("Patient_ID");

                        model.addRow(new Object[]{prescriptionId, description, patientId});
                    }

                    table.setModel(model);
                    con.close();

                    JOptionPane.showMessageDialog(contentPane, "Prescriptions successfully fetched\n Redirecting to doctor page", "Success", JOptionPane.INFORMATION_MESSAGE);
                    Doctor_1 obj1=new Doctor_1();
                    obj1.setVisible(true);
                    dispose();

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Invalid Doctor ID. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(contentPane, "Error occurred while fetching prescriptions.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnNewButton.setBounds(281, 159, 125, 33);
        contentPane.add(btnNewButton);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(32, 224, 668, 161);
        contentPane.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);

    }
}

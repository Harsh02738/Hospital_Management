/**
 * 
 */
/**
 * 
 */
module Hospital_Management_System {
	requires java.desktop;
	requires java.sql;
}